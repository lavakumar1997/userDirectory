import React, { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { UsersApi } from "../api/users.js";

function validate(values) {
  const e = {};

  const name = values.name.trim();
  if (!name) e.name = "Name is required";
  else if (name.length < 2 || name.length > 100) e.name = "Name must be 2–100 chars";

  const ageNum = Number(values.age);
  if (values.age === "" || Number.isNaN(ageNum)) e.age = "Age is required";
  else if (ageNum < 0 || ageNum > 120) e.age = "Age must be 0–120";

  if (!values.city.trim()) e.city = "City is required";
  if (!values.state.trim()) e.state = "State is required";

  const p = values.pincode.trim();
  if (!p) e.pincode = "Pincode is required";
  else if (p.length < 4 || p.length > 10) e.pincode = "Pincode must be 4–10 chars";

  return e;
}

export default function AddUser({ onToast }) {
  const nav = useNavigate();
  const [values, setValues] = useState({
    name: "",
    age: "",
    city: "",
    state: "",
    pincode: "",
  });
  const [touched, setTouched] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [apiError, setApiError] = useState("");

  const errors = useMemo(() => validate(values), [values]);
  const canSubmit = Object.keys(errors).length === 0 && !submitting;

  function setField(k, v) {
    setValues((s) => ({ ...s, [k]: v }));
  }

  async function onSubmit(e) {
    e.preventDefault();
    setApiError("");
    setTouched({ name: true, age: true, city: true, state: true, pincode: true });

    const currentErrors = validate(values);
    if (Object.keys(currentErrors).length > 0) return;

    try {
      setSubmitting(true);
      await UsersApi.create({
        name: values.name.trim(),
        age: Number(values.age),
        city: values.city.trim(),
        state: values.state.trim(),
        pincode: values.pincode.trim(),
      });

      onToast?.({ type: "success", message: "User created successfully" });
      nav("/list");
    } catch (e2) {
      setApiError(e2.message || "Failed to create user");
    } finally {
      setSubmitting(false);
    }
  }

  function errMsg(field) {
    return touched[field] ? errors[field] : "";
  }

  return (
    <div className="card">
      <h2>Add User</h2>

      {apiError ? <div className="error">{apiError}</div> : null}

      <form onSubmit={onSubmit} className="form">
        <div className="row">
          <label>Name</label>
          <input
            value={values.name}
            onChange={(e) => setField("name", e.target.value)}
            onBlur={() => setTouched((s) => ({ ...s, name: true }))}
            placeholder="Enter name"
          />
          {errMsg("name") ? <div className="field-error">{errMsg("name")}</div> : null}
        </div>

        <div className="row">
          <label>Age</label>
          <input
            value={values.age}
            onChange={(e) => setField("age", e.target.value)}
            onBlur={() => setTouched((s) => ({ ...s, age: true }))}
            placeholder="0 - 120"
            inputMode="numeric"
          />
          {errMsg("age") ? <div className="field-error">{errMsg("age")}</div> : null}
        </div>

        <div className="row">
          <label>City</label>
          <input
            value={values.city}
            onChange={(e) => setField("city", e.target.value)}
            onBlur={() => setTouched((s) => ({ ...s, city: true }))}
            placeholder="Enter city"
          />
          {errMsg("city") ? <div className="field-error">{errMsg("city")}</div> : null}
        </div>

        <div className="row">
          <label>State</label>
          <input
            value={values.state}
            onChange={(e) => setField("state", e.target.value)}
            onBlur={() => setTouched((s) => ({ ...s, state: true }))}
            placeholder="Enter state"
          />
          {errMsg("state") ? <div className="field-error">{errMsg("state")}</div> : null}
        </div>

        <div className="row">
          <label>Pincode</label>
          <input
            value={values.pincode}
            onChange={(e) => setField("pincode", e.target.value)}
            onBlur={() => setTouched((s) => ({ ...s, pincode: true }))}
            placeholder="4 - 10 chars"
          />
          {errMsg("pincode") ? (
            <div className="field-error">{errMsg("pincode")}</div>
          ) : null}
        </div>

        <div className="actions">
          <button className="btn" type="submit" disabled={!canSubmit}>
            {submitting ? "Saving..." : "Create User"}
          </button>
        </div>
      </form>
    </div>
  );
}