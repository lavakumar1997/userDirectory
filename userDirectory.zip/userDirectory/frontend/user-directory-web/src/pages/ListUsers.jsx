import React, { useEffect, useState } from "react";
import Spinner from "../components/Spinner.jsx";
import { UsersApi } from "../api/users.js";

export default function ListUsers() {
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [users, setUsers] = useState([]);

  useEffect(() => {
    let mounted = true;

    (async () => {
      try {
        setLoading(true);
        setErr("");
        const data = await UsersApi.list();
        if (mounted) setUsers(data);
      } catch (e) {
        if (mounted) setErr(e.message || "Failed to load users");
      } finally {
        if (mounted) setLoading(false);
      }
    })();

    return () => {
      mounted = false;
    };
  }, []);

  if (loading) {
    return (
      <div className="card center">
        <Spinner />
        <div className="muted">Loading users...</div>
      </div>
    );
  }

  if (err) {
    return (
      <div className="card">
        <h2>Users</h2>
        <div className="error">{err}</div>
      </div>
    );
  }

  return (
    <div className="card">
      <h2>Users</h2>

      {users.length === 0 ? (
        <div className="muted">No users found. Please add a user.</div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Age</th>
                <th>City</th>
                <th>State</th>
                <th>Pincode</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id}>
                  <td>{u.name}</td>
                  <td>{u.age}</td>
                  <td>{u.city}</td>
                  <td>{u.state}</td>
                  <td>{u.pincode}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}