import React from "react";
import { NavLink } from "react-router-dom";

export default function TopNav() {
  return (
    <header className="topbar">
      <div className="topbar-inner">
        <div className="brand">User Directory</div>
        <nav className="nav">
          <NavLink className={({ isActive }) => (isActive ? "active" : "")} to="/list">
            List
          </NavLink>
          <NavLink className={({ isActive }) => (isActive ? "active" : "")} to="/add">
            Add
          </NavLink>
        </nav>
      </div>
    </header>
  );
}