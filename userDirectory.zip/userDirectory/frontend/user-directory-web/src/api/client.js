export const API_BASE = import.meta.env.VITE_API_BASE ?? "http://localhost:5000";

export async function http(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });

  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const data = await res.json();
      // handle validation errors from ASP.NET
      if (data?.title) message = data.title;
      if (data?.errors) {
        const firstKey = Object.keys(data.errors)[0];
        if (firstKey) message = data.errors[firstKey]?.[0] ?? message;
      }
    } catch {
      // ignore
    }
    throw new Error(message);
  }

  if (res.status === 204) return null;
  return res.json();
}