import { http } from "./client";

export const UsersApi = {
  list: () => http("/api/users"),
  create: (payload) =>
    http("/api/users", { method: "POST", body: JSON.stringify(payload) }),
};