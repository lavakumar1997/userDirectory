import React, { useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import TopNav from "./components/TopNav.jsx";
import Toast from "./components/Toast.jsx";
import ListUsers from "./pages/ListUsers.jsx";
import AddUser from "./pages/AddUser.jsx";

export default function App() {
  const [toast, setToast] = useState(null);

  return (
    <div className="app-shell">
      <TopNav />
      <div className="container">
        <Routes>
          <Route path="/" element={<Navigate to="/list" replace />} />
          <Route path="/list" element={<ListUsers />} />
          <Route path="/add" element={<AddUser onToast={setToast} />} />
          <Route path="*" element={<Navigate to="/list" replace />} />
        </Routes>
      </div>

      <Toast toast={toast} onClose={() => setToast(null)} />
    </div>
  );
}