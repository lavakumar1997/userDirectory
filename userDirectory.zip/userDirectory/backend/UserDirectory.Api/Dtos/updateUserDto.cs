using System.ComponentModel.DataAnnotations;

namespace UserDirectory.Api.Dtos;

public class UpdateUserDto
{
    [Required, MinLength(2), MaxLength(100)]
    public string Name { get; set; } = string.Empty;

    [Range(0, 120)]
    public int Age { get; set; }

    [Required]
    public string City { get; set; } = string.Empty;

    [Required]
    public string State { get; set; } = string.Empty;

    [Required, MinLength(4), MaxLength(10)]
    public string Pincode { get; set; } = string.Empty;
}